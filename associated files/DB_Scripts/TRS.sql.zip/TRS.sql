-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 19, 2019 at 09:23 AM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `TRS`
--
CREATE DATABASE IF NOT EXISTS `TRS` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `TRS`;

-- --------------------------------------------------------

--
-- Table structure for table `ClassPrice`
--

CREATE TABLE `ClassPrice` (
  `ID` int(11) NOT NULL,
  `FK_TrainID` int(11) NOT NULL,
  `FK_ClassID` int(11) NOT NULL,
  `PricePerSeat` decimal(12,2) DEFAULT NULL,
  `PricePerCompartment` decimal(12,2) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `GenderID` int(11) NOT NULL,
  `Description` varchar(20) NOT NULL,
  `isActive` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`GenderID`, `Description`, `isActive`) VALUES
(1, 'Male', 1),
(2, 'Female', 1),
(3, 'Other', 1);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int(11) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `isActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `Description`, `isActive`) VALUES
(1, 'Administrator', 1),
(2, 'Authenticated User', 1),
(3, 'Premium Member', 1),
(4, 'Free', 1);

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `StationID` int(11) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `DescriptionLong` varchar(1000) NOT NULL,
  `DistanceFromMainStation` decimal(12,2) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`StationID`, `Description`, `DescriptionLong`, `DistanceFromMainStation`, `isActive`) VALUES
(1, 'Colombo Fort', 'Colombo Fort', '0.00', 1),
(2, 'MATARA', 'MATARA', '344.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tokenRecord`
--

CREATE TABLE `tokenRecord` (
  `RecordID` int(11) NOT NULL,
  `FK_TypeID` int(11) NOT NULL,
  `Token` varchar(15) DEFAULT NULL,
  `FK_userID` int(11) NOT NULL,
  `sendDate` datetime DEFAULT NULL,
  `ExpireDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tokenRecord`
--

INSERT INTO `tokenRecord` (`RecordID`, `FK_TypeID`, `Token`, `FK_userID`, `sendDate`, `ExpireDate`) VALUES
(1, 1, '4OE54i8rHftezJR', 1, '2019-05-10 09:32:16', '2019-05-10 11:32:16'),
(2, 1, 'k', 1, '2019-05-10 09:41:17', '2019-05-10 11:41:17'),
(3, 1, 'p', 1, '2019-05-10 09:42:35', '2019-05-10 11:42:35'),
(4, 1, 'w', 1, '2019-05-10 09:42:35', '2019-05-10 11:42:35'),
(5, 1, 'uS2R84kidQimgyf', 1, '2019-05-16 07:23:52', '2019-05-16 09:23:52'),
(6, 1, 'AEvpw2ifxNlfem1', 1, '2019-05-16 07:26:34', '2019-05-16 09:26:34'),
(7, 1, 'tneCECwYnViZDs5', 1, '2019-05-16 11:19:22', '2019-05-16 13:19:22'),
(8, 1, '0WjXgUgxaUm3FL9', 1, '2019-05-16 12:32:16', '2019-05-16 14:32:16'),
(9, 1, 'xozXJA7kOwztrwc', 1, '2019-05-16 19:56:24', '2019-05-16 21:56:24'),
(10, 1, 'RDfiI5Ozhkigmfw', 1, '2019-05-16 22:00:44', '2019-05-17 00:00:44'),
(11, 1, 'xWGzlPvCeEHoSPf', 1, '2019-05-17 06:56:39', '2019-05-17 08:56:39'),
(12, 1, '01AcjEXsuRgznG7', 1, '2019-05-17 10:26:58', '2019-05-17 12:26:58'),
(13, 1, '1XDYFH7PERdwoOx', 1, '2019-05-17 10:43:50', '2019-05-17 12:43:50'),
(14, 1, 'boavX8RByyUi6wI', 1, '2019-05-17 10:48:07', '2019-05-17 12:48:07'),
(15, 1, 'c5cIkUbP4Da0Yjh', 1, '2019-05-17 18:25:33', '2019-05-17 20:25:33'),
(16, 1, 'eaA4cedZhtJciU4', 1, '2019-05-17 22:02:45', '2019-05-18 00:02:45');

-- --------------------------------------------------------

--
-- Table structure for table `tokentype`
--

CREATE TABLE `tokentype` (
  `TokenID` int(11) NOT NULL,
  `TokenDescription` varchar(20) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tokentype`
--

INSERT INTO `tokentype` (`TokenID`, `TokenDescription`, `isActive`) VALUES
(1, 'PasswordReset', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `TrainID` int(11) NOT NULL,
  `TrainCode` int(11) NOT NULL,
  `TrainName` varchar(100) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `IsRegularRun` tinyint(1) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`TrainID`, `TrainCode`, `TrainName`, `Description`, `IsRegularRun`, `isActive`) VALUES
(1, 1121, 'Ruhunu Kumari', 'Test', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `trainClassDetails`
--

CREATE TABLE `trainClassDetails` (
  `ID` int(11) NOT NULL,
  `FK_TrainID` int(11) NOT NULL,
  `FK_ClassID` int(11) NOT NULL,
  `NoOfCompartments` int(11) NOT NULL,
  `NoOfSeats` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trainClassDetails`
--

INSERT INTO `trainClassDetails` (`ID`, `FK_TrainID`, `FK_ClassID`, `NoOfCompartments`, `NoOfSeats`) VALUES
(1, 1, 1, 3, 20),
(2, 1, 2, 4, 50);

-- --------------------------------------------------------

--
-- Table structure for table `trainClasses`
--

CREATE TABLE `trainClasses` (
  `ClassID` int(11) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `isActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trainClasses`
--

INSERT INTO `trainClasses` (`ClassID`, `Description`, `isActive`) VALUES
(1, 'Class A', 1),
(2, 'Class B', 1),
(3, 'Class C', 1);

-- --------------------------------------------------------

--
-- Table structure for table `trainSchedule`
--

CREATE TABLE `trainSchedule` (
  `ScheduleID` int(11) NOT NULL,
  `FK_TrainID` int(11) NOT NULL,
  `FK_From` int(11) NOT NULL,
  `FK_To` int(11) NOT NULL,
  `FromTile` decimal(6,2) NOT NULL,
  `ToTitle` decimal(6,2) NOT NULL,
  `isActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `FK_RoleID` int(11) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `Email` varchar(200) NOT NULL,
  `FK_GenderID` int(11) NOT NULL,
  `ContactNo` varchar(50) DEFAULT NULL,
  `DOB` date NOT NULL,
  `Password` varchar(300) NOT NULL,
  `LastLoginDate` date DEFAULT NULL,
  `FailedLoginAttempt` int(11) NOT NULL DEFAULT '0',
  `FailedLoginDate` date DEFAULT NULL,
  `AccountVerified` tinyint(1) NOT NULL DEFAULT '0',
  `isLocked` tinyint(1) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FK_RoleID`, `FirstName`, `LastName`, `Email`, `FK_GenderID`, `ContactNo`, `DOB`, `Password`, `LastLoginDate`, `FailedLoginAttempt`, `FailedLoginDate`, `AccountVerified`, `isLocked`, `isActive`) VALUES
(1, 1, 'shalitha', 'senanayaka', 'shalithax@gmail.com', 1, '1231231231', '2019-05-14', 'cKzJhKqFVM2WVd2CLWU3hQ==', '2019-05-19', 0, '2019-05-17', 1, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ClassPrice`
--
ALTER TABLE `ClassPrice`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_TrainID` (`FK_TrainID`),
  ADD KEY `FK_ClassID` (`FK_ClassID`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`GenderID`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`StationID`);

--
-- Indexes for table `tokenRecord`
--
ALTER TABLE `tokenRecord`
  ADD PRIMARY KEY (`RecordID`),
  ADD KEY `FK_TypeID` (`FK_TypeID`),
  ADD KEY `FK_userID` (`FK_userID`);

--
-- Indexes for table `tokentype`
--
ALTER TABLE `tokentype`
  ADD PRIMARY KEY (`TokenID`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`TrainID`);

--
-- Indexes for table `trainClassDetails`
--
ALTER TABLE `trainClassDetails`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_TrainID` (`FK_TrainID`),
  ADD KEY `FK_ClassID` (`FK_ClassID`);

--
-- Indexes for table `trainClasses`
--
ALTER TABLE `trainClasses`
  ADD PRIMARY KEY (`ClassID`);

--
-- Indexes for table `trainSchedule`
--
ALTER TABLE `trainSchedule`
  ADD PRIMARY KEY (`ScheduleID`),
  ADD KEY `FK_TrainID` (`FK_TrainID`),
  ADD KEY `FK_From` (`FK_From`),
  ADD KEY `FK_To` (`FK_To`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `FK_RoleID` (`FK_RoleID`),
  ADD KEY `FK_GenderID` (`FK_GenderID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ClassPrice`
--
ALTER TABLE `ClassPrice`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `GenderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `StationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tokenRecord`
--
ALTER TABLE `tokenRecord`
  MODIFY `RecordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tokentype`
--
ALTER TABLE `tokentype`
  MODIFY `TokenID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `train`
--
ALTER TABLE `train`
  MODIFY `TrainID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trainClassDetails`
--
ALTER TABLE `trainClassDetails`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trainClasses`
--
ALTER TABLE `trainClasses`
  MODIFY `ClassID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `trainSchedule`
--
ALTER TABLE `trainSchedule`
  MODIFY `ScheduleID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ClassPrice`
--
ALTER TABLE `ClassPrice`
  ADD CONSTRAINT `classprice_ibfk_1` FOREIGN KEY (`FK_TrainID`) REFERENCES `train` (`TrainID`),
  ADD CONSTRAINT `classprice_ibfk_2` FOREIGN KEY (`FK_ClassID`) REFERENCES `trainClasses` (`ClassID`);

--
-- Constraints for table `tokenRecord`
--
ALTER TABLE `tokenRecord`
  ADD CONSTRAINT `tokenrecord_ibfk_1` FOREIGN KEY (`FK_TypeID`) REFERENCES `tokentype` (`TokenID`),
  ADD CONSTRAINT `tokenrecord_ibfk_2` FOREIGN KEY (`FK_userID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `trainClassDetails`
--
ALTER TABLE `trainClassDetails`
  ADD CONSTRAINT `trainclassdetails_ibfk_1` FOREIGN KEY (`FK_TrainID`) REFERENCES `train` (`TrainID`),
  ADD CONSTRAINT `trainclassdetails_ibfk_2` FOREIGN KEY (`FK_ClassID`) REFERENCES `trainClasses` (`ClassID`);

--
-- Constraints for table `trainSchedule`
--
ALTER TABLE `trainSchedule`
  ADD CONSTRAINT `trainschedule_ibfk_1` FOREIGN KEY (`FK_TrainID`) REFERENCES `train` (`TrainID`),
  ADD CONSTRAINT `trainschedule_ibfk_2` FOREIGN KEY (`FK_From`) REFERENCES `station` (`StationID`),
  ADD CONSTRAINT `trainschedule_ibfk_3` FOREIGN KEY (`FK_To`) REFERENCES `station` (`StationID`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`FK_RoleID`) REFERENCES `role` (`RoleID`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`FK_GenderID`) REFERENCES `gender` (`GenderID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
